module.exports = {
  userModel: require("./user-model"),
  courseModel: require("./course-model"),
};
